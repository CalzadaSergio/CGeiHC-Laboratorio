#version 330

// Salida de color a la pantalla
out vec4 FragColor;

// El color que envías desde C++ al cambiar las piezas (ej. glm::vec3(0.0f, 1.0f, 0.0f))
uniform vec3 color;

void main()
{
    // Aplica el color con opacidad total (1.0)
    FragColor = vec4(color, 1.0);
}