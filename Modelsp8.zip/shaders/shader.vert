#version 330

// Recibe las posiciones de los vértices (layout 0 coincide con la clase Mesh)
layout (location = 0) in vec3 pos;

// Matrices que envías desde C++
uniform mat4 model;
uniform mat4 projection;
uniform mat4 view;

void main()
{
    // Calcula la posición final en la pantalla
    gl_Position = projection * view * model * vec4(pos, 1.0);
}